import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.*;

// Classe Affichage , classe qui permet de ger� les listener et l'affichage
public class Affichage extends JFrame{


	private static final long serialVersionUID = 1L;
	private JButton solution_precedente ;
	private JButton solution_suivante ;
	private JLabel Nb_solutions ;
	private JLabel solution_courante ;
	private Labyrinthe laby ;
	private Fenetre f;
	private int indice_premier_chemin ;
	private int indice_dernier_chemin ;
	private int i ;
	private int nb ;
	
	
	public Affichage(Labyrinthe l) throws FileNotFoundException, IOException // Cr�ation de la fen�tre
	{
		super(); 
		this.setPreferredSize(new Dimension(800,800));
		JPanel jp= new JPanel();
		JPanel jp2 = new JPanel() ;
		this.setLayout(new BorderLayout());
		this.getContentPane().add(jp,BorderLayout.NORTH);
		this.getContentPane().add(jp2,BorderLayout.SOUTH);
		laby = l;
		f= new Fenetre(laby);
		i = 0 ;
		solution_precedente= new JButton("Solution precedente");
		solution_suivante= new JButton("Solution suivante");
		nb= laby.getLchemin().size();
		Nb_solutions = new JLabel("il y a " + nb + " solutions");
		solution_courante = new JLabel(""+ i+ "/"+ nb);
		jp.add(Nb_solutions,BorderLayout.NORTH);
		jp.add(solution_precedente,BorderLayout.NORTH);
		jp.add(solution_suivante,BorderLayout.NORTH);
		jp2.add(solution_courante,BorderLayout.SOUTH);
		this.getContentPane().add(f,BorderLayout.CENTER);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.pack();
		this.setVisible(true);
		
		
		solution_suivante.addActionListener(new ActionListener(){ // Si on clique sur le bouton solution suivante , alors on affiche la solution suivante
			public void actionPerformed(ActionEvent e) {
				i++ ;
				solution_courante.setText(""+ i+ "/"+ nb);
				laby.setNB(laby.getNB()+1);
				
				
				if(laby.getNB() >= laby.getLchemin().size() )
				{
					i = 0;
					solution_courante.setText(""+ i+ "/"+ nb);
					laby.setNB(0);
					
					
				}
				
					f.construit(laby);
				
			}
			
		});
		
		solution_precedente.addActionListener(new ActionListener(){ // M�me chose qu'avant mais pour la solution pr�c�dente
			public void actionPerformed(ActionEvent e) {
				i-- ;
				solution_courante.setText(""+ i + "/"+ nb);
				laby.setNB(laby.getNB()-1);
				
				
				if(laby.getNB() <= -1)
				{
					laby.setNB(laby.getLchemin().size() - 1);
					i=nb ;
					solution_courante.setText(""+ i+ "/"+ nb);
				}
					
				f.construit(laby);
					
			}
			
		});
		
		
		
		
	}
	
	
	
}
