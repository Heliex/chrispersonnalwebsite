import java.awt.Color;
import java.awt.GridLayout;

import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

// Classe Fenetre , classe qui permet de ger� l'affichage du labyrinthe
public class Fenetre extends JPanel {
	
	
	private static final long serialVersionUID = 1L;


	public Fenetre(Labyrinthe lab){ // Constructeur qui construit l'interface a partir d'un labyrinthe
		;
		 setLayout( new GridLayout(lab.getNbLigne(), lab.getNbColonne()));
		 JPanel place = new JPanel();
		 for(int i= 0; i<lab.getNbLigne(); i++){
			 for(int j=0; j< lab.getNbColonne(); j++){
				 place = new JPanel();
				 place.setBorder(BorderFactory.createLineBorder(Color.gray)); // On met les bordures de chaque cases en gris
				 this.add(place);
				 if( i== lab.getEntree().getLigne() && j == lab.getEntree().getColone()) // Si on est a l'entr�e , on colorie la case en jaune
					 place.setBackground(Color.YELLOW);
				 if((lab.getTab())[i][j] == false){
					 place.setBackground(Color.BLACK); // Si la case est a faux , on la colorie en noire
				 }
				 
			 }
		 }
		 try
		 {
		 lab.resoudre(new ArrayList<Place>(),lab.Entree); // On resout le labyrinthe
		 construit(lab); // on le construit
		 }
		 catch(IndexOutOfBoundsException IoBe)
		 {
			 System.out.println("Aucune solution");
		 }
		 
		 
		 
		 
	}

	
	public void construit(Labyrinthe lab)
	{
		this.removeAll();
		this.setLayout(new GridLayout(lab.getNbLigne(),lab.getNbColonne())) ;
		for(int i = 0 ; i < lab.getNbLigne();i++)
		 {
			 for(int j = 0 ; j < lab.getNbColonne(); j++)
			 {
				 JPanel place_a_colorier = new JPanel();
				 place_a_colorier.setBorder(BorderFactory.createLineBorder(Color.gray));
				 if(lab.getEntree().getColone() == j && lab.getEntree().getLigne() == i)
					 place_a_colorier.setBackground(Color.YELLOW);
				 else
				 {
					 if(( lab.getLchemin().size() != 0) && lab.getLchemin().get(lab.getNB()).contains(new Place(i,j)) )
					 {
						 place_a_colorier.setBackground(Color.PINK); // Si la case fait partie d'un chemin , on la colorie en rose
			
					 }
					 else
					 {
						 if(lab.getTab()[i][j]) // sinon si la case est a vrai 
						 {
							 place_a_colorier.setBackground(Color.WHITE); // On la met a blanc
						 }
						 else
							 place_a_colorier.setBackground(Color.BLACK); // Sinon a noir
					 }
				 }
				 this.add(place_a_colorier);
				 validate();
			 }
		 }
	}
		
	
	
	
}
