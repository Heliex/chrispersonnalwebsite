
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
// Classe Labyrinthe permettant de cr�e et de r�soude le labyrinthe
public class Labyrinthe {

	private boolean tab[][];
	public Place Entree;
	private int NbColonne;
	private int NbLigne;
	private ArrayList<ArrayList<Place>> lchemin;
	private int NB ;
	
	public int getNB() {
		return NB;
	}


	public void setNB(int nB) {
		NB = nB;
	}


	public Labyrinthe(String fichier) throws FileNotFoundException, IOException{ // Constructeur qui permet de construire un labyrinthe a partir d'un fichier
		BufferedReader f= new BufferedReader(new FileReader(fichier));
		int i= 1;
		String s= f.readLine();
		int taillex= s.length();
		while(f.readLine() != null){
			i++;
		}
		tab= new boolean[i][taillex];
		this.NbLigne= i;
		this.NbColonne= taillex;
		f.close();
		this.Entree =remplir(fichier);
		this.lchemin = new ArrayList<ArrayList<Place>>(); 
		this.NB = 0 ;
		
	}
	

	private Place remplir(String fichier) throws FileNotFoundException, IOException{ // Methode qui permet de construite le labyrinthe a partir du fichier
		BufferedReader f= new BufferedReader(new FileReader(fichier));
		String s= f.readLine();
		Place ent= null;
		int ligne= 0;
		do{
			for(int i= 0; i<s.length(); i++){
				char ch= s.charAt(i);
				if(ch == '#'){
					tab[ligne][i]= false;
				}else if(ch == 'E'){
					tab[ligne][i]= true;
					ent = new Place(ligne, i);
				}else if(ch == '0'){
					tab[ligne][i]= true;
				}
			}
			ligne++;	
			s =f.readLine();
		}while(s != null);
		f.close();
		return ent;
	}
	
	public boolean[][] getTab(){
		return tab;
	}

	public int getNbColonne() {
		return NbColonne;
	}

	public void setNbColonne(int nbColonne) {
		NbColonne = nbColonne;
	}

	public int getNbLigne() {
		return NbLigne;
	}

	public void setNbLigne(int nbLigne) {
		NbLigne = nbLigne;
	}
	
	public void resoudre(ArrayList<Place> chemin, Place current){ // M�thode de r�solution du labyrinthe
		if((current.getLigne()== 0 || current.getLigne()== NbLigne-1 || current.getColone()== 0 || current.getColone()== NbColonne-1)&& !(Entree.equals(current))) {// Si on se trouve a la sortie , alors c'est le cas trivial
			chemin.add(current); // On ajoute la place courante a la liste de place
			ArrayList<Place> chemin_fini = new ArrayList<Place>(chemin); // On cr�e une copie de la liste chemin
			lchemin.add(chemin_fini); // On l'ajoute a la liste des chemins
			chemin.remove(current); // On retire la place courante de la liste de place pour revenir en arriere
			
			}else{ // Sinon 
			
			chemin.add(current); // On ajoute la place courante a la liste de place
			Place gauche= new Place(current.getLigne(), current.getColone()-1); // On d�finit les 4 directions autour de la place
			Place droite= new Place(current.getLigne(), current.getColone()+1);
			Place dessous= new Place(current.getLigne()+1, current.getColone());
			Place dessus= new Place(current.getLigne()-1, current.getColone());
			
			Place tab_place[]= {gauche,droite,dessous,dessus} ;
			for(int i = 0 ; i < 4 ; i++)
			{
				
				if(tab_place[i].getColone() != -1 && tab_place[i].getLigne() != -1 && tab_place[i].getColone() != NbColonne && tab_place[i].getLigne() != NbLigne ) // Si on est pas en dehors du labyrinthe
				if(tab[tab_place[i].getLigne()][tab_place[i].getColone()] && !chemin.contains(tab_place[i]))	 // Si la place suivante est a vrai , et qu'elle n'est pas contenu dans la liste de place
				{
					
					resoudre(chemin,tab_place[i]);	// Alors on continue de resoudre
					
				}
			}
			chemin.remove(current); // On retire la place courante de la liste de place
			}
		
	}


	public Place getEntree() {
		return Entree;
	}


	public void setEntree(Place entree) {
		Entree = entree;
	}


	public ArrayList<ArrayList<Place>> getLchemin() {
		return lchemin;
	}


	public void setLchemin(ArrayList<ArrayList<Place>> lchemin) {
		this.lchemin = lchemin;
	}
	

	
}