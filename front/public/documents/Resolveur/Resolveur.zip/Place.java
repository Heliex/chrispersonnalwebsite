// Classe Place qui permet de d�termin� une place dans le labyrinthe
public class Place {

	private int ligne; 
	private int colone;
	
	public Place(int x, int y){
		this.ligne= x;
		this.colone= y;
	}

	public int getLigne() {
		return ligne;
	}

	public void setLigne(int ligne) {
		this.ligne = ligne;
	}

	public int getColone() {
		return colone;
	}

	public void setColone(int colone) {
		this.colone = colone;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + colone;
		result = prime * result + ligne;
		return result;
	}

	@Override
	public boolean equals(Object obj) { // On est obliger de red�finir equals car on utilise contains dans nos autres classe sur une Place
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Place other = (Place) obj;
		if (colone != other.colone)
			return false;
		if (ligne != other.ligne)
			return false;
		return true;
	}


	
}
