// M�thode main du programme qui permet d'effectuer les tests des programmes !
import java.io.FileNotFoundException;
import java.io.IOException;



public class Test {
	
	public static void main(String [] args) throws FileNotFoundException, IOException {
		String s = args[0];
		Labyrinthe laby = new Labyrinthe(s); // On cr�e un nouveau labyrinthe avec le labyrinthe passer en param�tres	
		new Affichage(laby) ; // Puis on l'affiche 
	}
		

}
